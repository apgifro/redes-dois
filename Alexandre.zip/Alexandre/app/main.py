"""
Alexandre Girardello - UTF-8 - pt-br - 2023-09-11
main.py
"""

import curses
import time
from app.cpf import valida_cpf
from app.name import valida_nome


class App:
    def __init__(self, stdscr):
        self.stdscr = stdscr
        self.run()

    def get_user_cpf(self, prev_input='', prev_input_formatted=''):
        cpf_numeric = prev_input
        cursor_position = len(prev_input)
        cpf_formatted = prev_input_formatted
        msg_start = f'Digite o CPF: '
        self.stdscr.addstr(0, 0, msg_start + ' ' * 20)
        self.stdscr.addstr(0, len(msg_start), cpf_formatted)
        self.stdscr.refresh()

        while True:
            character = self.stdscr.getch()

            if character == ord('\n') or character == ord('\r'):
                break

            elif character in [curses.KEY_BACKSPACE, 127]:
                if cursor_position > 0:
                    cpf_numeric = cpf_numeric[:cursor_position - 1] + cpf_numeric[cursor_position:]
                    cursor_position -= 1

            elif ord('0') <= character <= ord('9') and len(cpf_numeric) < 11:
                cpf_numeric = cpf_numeric[:cursor_position] + chr(character) + cpf_numeric[cursor_position:]
                cursor_position += 1

            elif character == curses.KEY_LEFT:
                cursor_position = max(0, cursor_position - 1)

            elif character == curses.KEY_RIGHT:
                cursor_position = min(len(cpf_numeric), cursor_position + 1)

            elif character == curses.KEY_DC:
                if cursor_position < len(cpf_numeric):
                    cpf_numeric = cpf_numeric[:cursor_position] + cpf_numeric[cursor_position + 1:]

            cpf_formatted = ''.join(
                [cpf_numeric[i:i+3] + ('.' if i < 6 else '-' if i == 6 else '') for i in range(0, len(cpf_numeric), 3)]
            )

            cursor_position_formatted = cursor_position + cursor_position // 3

            if cursor_position > 6:
                cursor_position_formatted += 1

            self.stdscr.addstr(0, 0, ' ' * (len(msg_start) + 20))
            self.stdscr.addstr(0, 0, msg_start)
            self.stdscr.addstr(0, len(msg_start), cpf_formatted)
            self.stdscr.move(0, len(msg_start) + cursor_position_formatted - (1 if cursor_position > 6 else 0))

            self.stdscr.refresh()

        return cpf_numeric, cpf_formatted

    def get_user_name(self, prev_input=''):
        name = prev_input
        cursor_position = len(prev_input)
        msg_start = 'Digite o nome: '
        self.stdscr.addstr(0, 0, msg_start + ' ' * 20)
        self.stdscr.addstr(0, len(msg_start), name)
        self.stdscr.refresh()

        while True:
            character = self.stdscr.getch()

            if character == ord('\n') or character == ord('\r'):
                break

            elif character in [curses.KEY_BACKSPACE, 127]:
                if cursor_position > 0:
                    name = name[:cursor_position - 1] + name[cursor_position:]
                    cursor_position -= 1

            elif character == curses.KEY_LEFT:
                cursor_position = max(0, cursor_position - 1)

            elif character == curses.KEY_RIGHT:
                cursor_position = min(len(name), cursor_position + 1)

            elif character == curses.KEY_DC:
                if cursor_position < len(name):
                    name = name[:cursor_position] + name[cursor_position + 1:]

            elif len(name) < 40:
                name = name[:cursor_position] + chr(character) + name[cursor_position:]
                cursor_position += 1

            self.stdscr.addstr(0, 0, ' ' * (len(msg_start) + 50))
            self.stdscr.addstr(0, 0, msg_start)
            self.stdscr.addstr(0, len(msg_start), name)
            self.stdscr.move(0, len(msg_start) + cursor_position)

            self.stdscr.refresh()

        return name

    def run(self):
        cpf, cpf_formatted = '', ''
        self.stdscr.addstr(0, 0, 'Digite o CPF: ')
        self.stdscr.refresh()

        while True:
            cpf, cpf_formatted = self.get_user_cpf(cpf, cpf_formatted)
            self.stdscr.addstr(1, 0, ' ' * 80)

            if not cpf:
                self.stdscr.addstr(1, 0, f'\nEncerrando o script...\n')
                self.stdscr.refresh()
                time.sleep(1)
                break

            elif valida_cpf(cpf):
                self.stdscr.addstr(1, 0, f'\nCPF: {cpf_formatted}\n')
                self.stdscr.refresh()

                while True:
                    nome = self.get_user_name()
                    if not nome:
                        break

                    nome_valido = valida_nome(nome)

                    if nome_valido[0]:
                        self.stdscr.addstr(1, 0, f'\nCPF: {cpf_formatted}'
                                                 f'\nNome: {nome_valido[1]}'
                                                 f'\n\nTecle para encerrar o script...')
                        self.stdscr.refresh()
                        self.stdscr.getch()
                        break

                    else:
                        self.stdscr.addstr(1, 0, f'\n{nome_valido[2]} Por favor, tente novamente...')
                        self.stdscr.refresh()
                        time.sleep(1)
                        self.stdscr.addstr(1, 0, ' ' * 80)
                        self.stdscr.refresh()

                if not nome:
                    continue
                break

            else:
                self.stdscr.addstr(1, 0, f'\nCPF inválido! Por favor, tente novamente...')
                self.stdscr.refresh()
                time.sleep(1)
                self.stdscr.addstr(1, 0, ' ' * 80)
                self.stdscr.refresh()


if __name__ == '__main__':
    curses.wrapper(App)
