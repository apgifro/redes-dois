"""
Alexandre Girardello - UTF-8 - pt-br - 2023-09-11
name.py
"""


def valida_nome(nome):
    erro = ''
    valido = False
    nome_valido = nome.strip()
    if len(nome) > 2:
        valido = True
        nome_v = nome_valido.split()
        nome_valido = ''
        for nomes in nome_v:
            nome_valido += nomes.strip() + ' '

        nome_valido = nome_valido.title()

        for nomes in nome_valido.split():
            if not nomes.isalpha():
                valido = False
                erro = 'Nome com caracteres especiais não é aceito.'
                break
    else:
        erro = 'Nome deve ter duas letras ou mais.'

    return valido, nome_valido, erro
