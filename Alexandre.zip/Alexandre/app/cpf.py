"""
Alexandre Girardello - UTF-8 - pt-br - 2023-09-11
cpf.py
"""

import re


def valida_cpf(cpf):
    cpf = ''.join(re.findall(r'\d', cpf))

    if len(cpf) != 11:
        return False

    if cpf == cpf[0] * 11:
        return False

    def calcula_digito(d):
        return  (11 - d % 11) % 10

    digito1 = sum(i * int(cpf[idx]) for idx, i in enumerate(range(10, 1, -1)))
    digito2 = sum(i * int(cpf[idx]) for idx, i in enumerate(range(11, 1, -1)))

    return cpf[-2:] == f'{calcula_digito(digito1)}{calcula_digito(digito2)}'
