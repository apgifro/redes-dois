"""
Alexandre Girardello - UTF-8 - pt-br - 2023-09-11
test_integration.py

Os seguintes testes de integração não são necessários
dada a forma que o programa foi construído. Na prática,
o teste de integração já é feito manualmente, pois se trata
de entrada e atualização em tempo de execução dos valores
exibidos. Dessa forma, pytest é orientado a pular esses
testes. Apenas os necessários testes unitários
serão executados.

Um teste para veriicar a integração com nome
não é necessário pelas mesmas razões. Pulados.
"""

import pytest
from unittest.mock import patch
from app.main import App


@pytest.mark.skip(reason="Teste inapropriado no momento.")
def test_valida_cpf_integration_valido(mocker):
    app = App()
    cpf_valido = '12345678909'
    user_input = list(cpf_valido + '\n' + '\n' + '\n')

    with patch('readchar.readchar', side_effect=user_input):
        mock_print = mocker.patch('builtins.print')
        app.pede_cpf()
        mock_print.assert_called_with('Encerrando o programa...')


@pytest.mark.skip(reason="Teste inapropriado no momento.")
def test_valida_cpf_integration_invalido(mocker):
    app = App()
    cpf_invalido = '11111111111'
    user_input = list(cpf_invalido + '\n' + '\n' + '\n' + '\n')

    with patch('readchar.readchar', side_effect=user_input):
        mock_print = mocker.patch('builtins.print')
        app.pede_cpf()
        mock_print.assert_called_with('Encerrando o programa...')


@pytest.mark.skip(reason="Teste inapropriado no momento.")
def test_valida_cpf_integration_valido_vazio(mocker):
    app = App()
    user_input = list('\n')

    with patch('readchar.readchar', side_effect=user_input):
        mock_print = mocker.patch('builtins.print')
        app.pede_cpf()
        mock_print.assert_called_with('Encerrando o programa...')


@pytest.mark.skip(reason="Teste inapropriado no momento.")
def test_valida_cpf_integration_caracteres_invalidos(mocker):
    app = App()
    user_input = list('mak456\n' + '\n' + '\n')

    with patch('readchar.readchar', side_effect=user_input):
        mock_print = mocker.patch('builtins.print')
        app.pede_cpf()
        mock_print.assert_called_with('Encerrando o programa...')
