"""
Alexandre Girardello - UTF-8 - pt-br - 2023-09-11
test_name.py
"""

import unittest
from app.name import valida_nome


class TestName(unittest.TestCase):
    def test_valida_nome_valido(self):
        nome_valido = "  alexandre   prestes  de girardello"
        self.assertTrue(valida_nome(nome_valido)[0])

    def test_valida_nome_invalido(self):
        nome_invalido = "nome com car4cteres esp%ciais"
        self.assertFalse(valida_nome(nome_invalido)[0])

    def test_valida_nome_pequeno(self):
        nome_invalido = "ab"
        self.assertFalse(valida_nome(nome_invalido)[0])


if __name__ == '__main__':
    unittest.main()
