"""
Alexandre Girardello - UTF-8 - pt-br - 2023-09-11
test_cpf.py
"""

import unittest
from app.cpf import valida_cpf


class TestValidaCpf(unittest.TestCase):
    def test_valida_cpf_valido(self):
        # Testa um CPF válido
        cpf_valido = "123.456.789-09"
        self.assertTrue(valida_cpf(cpf_valido), 'A função não validou corretamente um CPF inválido')

    def test_valida_cpf_invalido(self):
        # Testa um CPF inválido
        cpf_invalido = "111.222.333-44"
        self.assertFalse(valida_cpf(cpf_invalido), 'A função não reconheceu corretamente um CPF inválido')


if __name__ == '__main__':
    unittest.main()
